package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;

public interface EmployeeService {
	public int addEmployee(Employee employee);
	public Employee getEmployee(int eid);
	public Employee updateEmployee(Employee employee);
	public ArrayList<Employee> getEmployeeList(String employeeProject);

}
