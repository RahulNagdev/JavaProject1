package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dao.EmployeeDAO;
import com.cg.employee.dao.EmployeeDAOImpl;
import com.cg.employee.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService {

EmployeeDAO dao;
	public EmployeeServiceImpl(){
	 dao = new EmployeeDAOImpl();
	}
	public int addEmployee(Employee employee){
		int ei=dao.addEmployee(employee);
		return ei;
	}

	@Override
	public Employee getEmployee(int eid) {
		// TODO Auto-generated method stub
		return dao.getEmployee(eid);
}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(employee);
			}

	@Override
	public ArrayList<Employee> getEmployeeList(String employeeProject) {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(employeeProject);
	}

}
