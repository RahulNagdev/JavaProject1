package com.cg.employee.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;

public class Main {
	public static void main(String args[]){
		EmployeeService service=new EmployeeServiceImpl();
		int ch=0;
		Scanner sc=new Scanner(System.in);
		do{
		
		System.out.println("1. Add Employee ");
		System.out.println("2. Display Employee Details");
		System.out.println("3. Update Details");
		System.out.println("4.Display Employee List based on Project");
		System.out.println("5.Exit");
		System.out.println("Enter Your Choice");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:

			System.out.println("Enter Employee Name :");
			String name=sc.next();
			System.out.println("Enter Employee MobileNo: ");
			String mob=sc.next();
			System.out.println("Enter Employee Salary: ");
			double salary=sc.nextDouble();
			System.out.println("Enter Employee Project: ");
			String proj=sc.next();
			Employee employee=new Employee();
			
		employee.setEmployeeName(name);
			employee.setEmployeeMobNo(mob);
			employee.setEmployeeSalary(salary);
		employee.setEmployeeProject(proj);
			
			
			int eid= service.addEmployee(employee);
		System.out.println("Employee Record Added with Employee Id "+eid);
		break;
		case 2:
			System.out.println("Enter Employee Id : ");
			eid=sc.nextInt();
			employee=service.getEmployee(eid);
			if(employee==null)
				System.err.println("Record Not Found");
			else{
		System.out.println(employee.getEmployeeName());
		System.out.println(employee.getEmployeeMobNo());
		System.out.println(employee.getEmployeeSalary());
		System.out.println(employee.getEmployeeProject());
			}break;	
		case 3:
			System.out.println("Enter EmployeeId: ");
			eid=sc.nextInt();
			employee=service.getEmployee(eid);
			if(employee==null)
				System.err.println("Record Not Found");
			else{
				System.out.println("Enter New Mobile No");
				 mob=sc.next();
				employee.setEmployeeMobNo(mob);
				employee=service.updateEmployee(employee);
				System.out.println("Record Updated");
				System.out.println(employee.getEmployeeName());
				System.out.println(employee.getEmployeeMobNo());
			
			}
		break;
		case 4:
			System.out.println("Enter Employee Project");
			proj=sc.next();
			ArrayList<Employee> list=service.getEmployeeList(proj);
			if(list.size()==0)
				System.out.println("No Student enrolled to this Course");
			else{
				for(Employee s:list){
					System.out.println(s.getEmployeeName()+" "+s.getEmployeeMobNo());
				}
			}
		}
			}
		
		while(ch!=5);
	}}